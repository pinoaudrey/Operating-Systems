var searchData=
[
  ['sig_115',['sig',['../structKillCommand.html#a20f5367bbec80a936189c57b1f9db351',1,'KillCommand']]],
  ['sig_5fstr_116',['sig_str',['../structKillCommand.html#a879a36b90427ec640bef5c92a6c9c24e',1,'KillCommand']]],
  ['simple_117',['simple',['../unionCommand.html#a269da4d9b16689de14a0ec83636b59e8',1,'Command']]],
  ['simplecommand_118',['SimpleCommand',['../structSimpleCommand.html',1,'SimpleCommand'],['../command_8h.html#aed38f2b4e4e2fbd87821818f1b56b4be',1,'SimpleCommand():&#160;command.h']]]
];
